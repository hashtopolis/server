

class GenericCracker:
    pass