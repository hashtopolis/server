import re
import signal
import sys
import platform
import logging
import time
from types import MappingProxyType
from pathlib import Path

import os
import shutil
import subprocess

from htpclient.dicts import copy_and_set_token, dict_clientError
from htpclient.jsonRequest import JsonRequest
from htpclient.config import Config


def log_error_and_exit(message):
    logging.error(message)
    sys.exit(1)


def print_speed(speed):
    prefixes = MappingProxyType(
        {0: "",
         1: "k",
         2: "M",
         3: "G",
         4: "T"})
    exponent = 0
    while speed > 1000:
        exponent += 1
        speed = float(speed) / 1000
    return str("{:6.2f}".format(speed)) + prefixes[exponent] + "H/s"


def get_bit():
    if platform.machine().endswith('64'):
        return "64"
    return "32"


def kill_hashcat(pid, get_os):
    if get_os != 1:
        os.killpg(os.getpgid(pid), signal.SIGTERM)
    else:
        subprocess.Popen("TASKKILL /F /PID {pid} /T".format(pid=pid))


def send_error(error, token, task_id, chunk_id):
    query = copy_and_set_token(dict_clientError, token)
    query['message'] = error
    query['chunkId'] = chunk_id
    query['taskId'] = task_id
    req = JsonRequest(query)
    req.execute()


def file_get_contents(filename):
    with open(filename) as f:
        return f.read()


def start_uftpd(os_extension, config):
    try:
        subprocess.check_output("killall -s 9 uftpd", shell=True)  # stop running service to make sure we can start it again
    except subprocess.CalledProcessError:
        pass  # ignore in case uftpd was not running
    path = retrieve_binary('uftpd' + os_extension)
    if not path:
        logging.error("uftpd binary not found, cant do multicast")
        return
    cmd = path + ' '
    if config.get_value('multicast-device'):
        cmd += "-I " + config.get_value('multicast-device') + ' '
    else:
        cmd += "-I eth0 "  # wild guess as default
    cmd += "-D " + os.path.abspath(config.get_value('files-path') + "/") + ' '
    cmd += "-L " + os.path.abspath("multicast/" + str(time.time()) + ".log")
    logging.debug("CALL: " + cmd)
    subprocess.check_output(cmd, shell=True)
    logging.info("Started multicast daemon")


def get_wordlist(command):
    split = clean_list(command.split(" "))
    for index, part in enumerate(split):
        if part[0] == '-':
            continue
        elif index == 0 or split[index - 1][0] != '-':
            return part
    return ''


def get_rules_and_hl(command, alias):
    split = clean_list(command.split(" "))
    rules = []
    for index, part in enumerate(split):
        if index > 0 and (split[index - 1] == '-r' or split[index - 1] == '--rules-file'):
            rules.append(split[index - 1])
            rules.append(split[index - 0])
        if part == alias:
            rules.append(part)
    return " ".join(rules)


def clean_list(element_list):
    index = 0
    for part in element_list:
        if not part:
            del element_list[index]
            index -= 1
        index += 1
    return element_list


# the prince flag is deprecated
def update_files(command, prince=False):
    config = Config()
    files_path = config.get_value('files-path')

    split = command.split(" ")
    ret = []
    for part in split:
        # test if file exists
        if not part:
            continue

        path = Path(files_path, part)
        if os.path.exists(path):
            ret.append(f'"{path}"')
            continue

        if '=' in part:
            key, value = part.split('=', 1)
            if value:
                # Accept both hintfile=file and hintfile="file" style arguments.
                if len(value) > 1 and value[0] == value[-1] and value[0] in ("'", '"'):
                    value = value[1:-1]
                value_path = Path(files_path, value)
                if os.path.exists(value_path):
                    ret.append(f'{key}="{value_path}"')
                    continue

        ret.append(str(part))
    return " %s " % " ".join(ret)


def escape_ansi(line):
    ansi_escape = re.compile(r'(\x9B|\x1B\[)[0-?]*[ -/]*[@-~]')
    return ansi_escape.sub('', line)

# function to retrieve a system or local binary.
def retrieve_binary(binary):
    cwd = Path.cwd()
    # use full path so that it works on Windows and Linux
    local_binary = cwd / binary

    # First check if there is a local binary and use that if it is there
    if local_binary.exists() and local_binary.is_file():
        return str(local_binary)

    # Fall back on system binary
    system_binary = shutil.which(binary)

    if system_binary:
        return system_binary
    return None